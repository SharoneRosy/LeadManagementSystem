package com.kam.lms.repository;

import com.kam.lms.model.Interaction;
import com.kam.lms.model.Lead;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface InteractionRepository extends JpaRepository<Interaction, Long> {
    List<Interaction> findByLead(Lead lead);
    List<Interaction> findByType(Interaction.Type type);
    long countByType(Interaction.Type type);
    List<Interaction> findByInteractionDateAfter(LocalDate date);
}
