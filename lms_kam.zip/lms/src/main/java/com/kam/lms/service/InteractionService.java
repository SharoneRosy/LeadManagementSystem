package com.kam.lms.service;

import com.kam.lms.model.Interaction;
import com.kam.lms.model.Lead;
import com.kam.lms.repository.InteractionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InteractionService {

    private final InteractionRepository interactionRepository;

    public InteractionService(InteractionRepository interactionRepository) {
        this.interactionRepository = interactionRepository;
    }

    public Interaction addInteraction(Interaction interaction) {
        return interactionRepository.save(interaction);
    }

    public List<Interaction> getAllInteractions() {
        return interactionRepository.findAll();
    }

    public Optional<Interaction> getInteractionById(Long id) {
        return interactionRepository.findById(id);
    }

    public List<Interaction> getInteractionsByLead(Lead lead) {
        return interactionRepository.findByLead(lead);
    }

    public List<Interaction> getInteractionsByType(Interaction.Type type) {
        return interactionRepository.findByType(type);
    }

    public void deleteInteraction(Long id) {
        interactionRepository.deleteById(id);
    }
}
