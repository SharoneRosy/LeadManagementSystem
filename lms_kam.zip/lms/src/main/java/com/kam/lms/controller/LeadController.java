package com.kam.lms.controller;

import com.kam.lms.model.Lead;
import com.kam.lms.model.Restaurant;
import com.kam.lms.model.User;
import com.kam.lms.service.LeadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/leads")
public class LeadController {

    private final LeadService leadService;

    public LeadController(LeadService leadService) {
        this.leadService = leadService;
    }

    @PostMapping
    public ResponseEntity<Lead> addLead(@RequestBody Lead lead) {
        return ResponseEntity.ok(leadService.addLead(lead));
    }

    @GetMapping
    public ResponseEntity<List<Lead>> getAllLeads() {
        return ResponseEntity.ok(leadService.getAllLeads());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Lead> getLeadById(@PathVariable Long id) {
        return leadService.getLeadById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Lead>> getLeadsByUser(@PathVariable Long userId) {
        User user = new User(); // Fetch user from a UserService (implement if required)
        user.setId(userId);
        return ResponseEntity.ok(leadService.getLeadsByUser(user));
    }

    @GetMapping("/restaurant/{restaurantId}")
    public ResponseEntity<List<Lead>> getLeadsByRestaurant(@PathVariable Long restaurantId) {
        Restaurant restaurant = new Restaurant(); // Fetch restaurant from a RestaurantService
        restaurant.setId(restaurantId);
        return ResponseEntity.ok(leadService.getLeadsByRestaurant(restaurant));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Lead>> getLeadsByStatus(@PathVariable Lead.Status status) {
        return ResponseEntity.ok(leadService.getLeadsByStatus(status));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLead(@PathVariable Long id) {
        leadService.deleteLead(id);
        return ResponseEntity.noContent().build();
    }
}
