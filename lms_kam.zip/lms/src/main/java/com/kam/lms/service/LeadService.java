package com.kam.lms.service;

import com.kam.lms.model.Lead;
import com.kam.lms.model.Restaurant;
import com.kam.lms.model.User;
import com.kam.lms.repository.LeadRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LeadService {

    private final LeadRepository leadRepository;

    public LeadService(LeadRepository leadRepository) {
        this.leadRepository = leadRepository;
    }

    public Lead addLead(Lead lead) {
        return leadRepository.save(lead);
    }

    public List<Lead> getAllLeads() {
        return leadRepository.findAll();
    }

    public Optional<Lead> getLeadById(Long id) {
        return leadRepository.findById(id);
    }

    public List<Lead> getLeadsByUser(User user) {
        return leadRepository.findByUser(user);
    }

    public List<Lead> getLeadsByRestaurant(Restaurant restaurant) {
        return leadRepository.findByRestaurant(restaurant);
    }

    public List<Lead> getLeadsByStatus(Lead.Status status) {
        return leadRepository.findByStatus(status);
    }

    public void deleteLead(Long id) {
        leadRepository.deleteById(id);
    }
}
