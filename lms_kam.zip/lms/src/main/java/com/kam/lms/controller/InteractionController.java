package com.kam.lms.controller;

import com.kam.lms.model.Interaction;
import com.kam.lms.model.Lead;
import com.kam.lms.service.InteractionService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/interactions")
public class InteractionController {

    private final InteractionService interactionService;

    public InteractionController(InteractionService interactionService) {
        this.interactionService = interactionService;
    }

    @PostMapping
    public ResponseEntity<Interaction> addInteraction(@RequestBody Interaction interaction) {
    	return ResponseEntity.ok(interactionService.addInteraction(interaction));
    }

    @GetMapping
    public ResponseEntity<List<Interaction>> getAllInteractions() {
        return ResponseEntity.ok(interactionService.getAllInteractions());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Interaction> getInteractionById(@PathVariable Long id) {
        return interactionService.getInteractionById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/lead/{leadId}")
    public ResponseEntity<List<Interaction>> getInteractionsByLead(@PathVariable Long leadId) {
        Lead lead = new Lead(); // Fetch lead from LeadService if necessary
        lead.setId(leadId);
        return ResponseEntity.ok(interactionService.getInteractionsByLead(lead));
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<List<Interaction>> getInteractionsByType(@PathVariable Interaction.Type type) {
        return ResponseEntity.ok(interactionService.getInteractionsByType(type));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInteraction(@PathVariable Long id) {
        interactionService.deleteInteraction(id);
        return ResponseEntity.noContent().build();
    }
}
