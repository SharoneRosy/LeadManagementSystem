package com.kam.lms.controller;

import com.kam.lms.model.CallPlanning;
import com.kam.lms.service.CallPlanningService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/call-planning")
public class CallPlanningController {

    private final CallPlanningService callPlanningService;

    public CallPlanningController(CallPlanningService callPlanningService) {
        this.callPlanningService = callPlanningService;
    }

    @PostMapping
    public ResponseEntity<CallPlanning> addOrUpdateCallPlanning(@RequestBody CallPlanning callPlanning) {
        return ResponseEntity.ok(callPlanningService.addOrUpdateCallPlanning(callPlanning));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CallPlanning> getCallPlanningById(@PathVariable Long id) {
        return callPlanningService.getCallPlanningById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/due-today")
    public ResponseEntity<List<CallPlanning>> getCallPlanningsDueToday() {
        return ResponseEntity.ok(callPlanningService.getCallPlanningsDueToday());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCallPlanning(@PathVariable Long id) {
        callPlanningService.deleteCallPlanning(id);
        return ResponseEntity.noContent().build();
    }
}
