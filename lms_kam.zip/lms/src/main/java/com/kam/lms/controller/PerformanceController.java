package com.kam.lms.controller;

import com.kam.lms.model.Interaction;
import com.kam.lms.service.PerformanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/performance")
public class PerformanceController {

    private final PerformanceService performanceService;

    public PerformanceController(PerformanceService performanceService) {
        this.performanceService = performanceService;
    }

    @GetMapping("/lead-status")
    public ResponseEntity<Map<String, Long>> getLeadStatusMetrics() {
        return ResponseEntity.ok(performanceService.getLeadStatusMetrics());
    }

    @GetMapping("/interaction-frequency")
    public ResponseEntity<List<Interaction>> getHighFrequencyInteractions(
            @RequestParam(required = false) LocalDate sinceDate) {
        if (sinceDate == null) {
            sinceDate = LocalDate.now().minusMonths(1); // Default to last month
        }
        return ResponseEntity.ok(performanceService.getHighFrequencyInteractions(sinceDate));
    }

    @GetMapping("/order-patterns")
    public ResponseEntity<Map<String, Long>> getOrderPatterns() {
        return ResponseEntity.ok(performanceService.getOrderPatterns());
    }

    @GetMapping("/kam-performance/{userId}")
    public ResponseEntity<Map<String, Object>> getKAMPerformance(@PathVariable Long userId) {
        return ResponseEntity.ok(performanceService.getKAMPerformance(userId));
    }
}
