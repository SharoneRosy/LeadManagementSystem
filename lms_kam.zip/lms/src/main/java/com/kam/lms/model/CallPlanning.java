package com.kam.lms.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "call_planning")
public class CallPlanning {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    @JoinColumn(name = "lead_id", nullable = false)
    private Lead lead;

    @Column(nullable = false)
    private int frequencyDays; // How often calls need to be made (in days)

    private LocalDate lastCallDate; // Date of the last call

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Lead getLead() {
		return lead;
	}

	public void setLead(Lead lead) {
		this.lead = lead;
	}

	public int getFrequencyDays() {
		return frequencyDays;
	}

	public void setFrequencyDays(int frequencyDays) {
		this.frequencyDays = frequencyDays;
	}

	public LocalDate getLastCallDate() {
		return lastCallDate;
	}

	public void setLastCallDate(LocalDate lastCallDate) {
		this.lastCallDate = lastCallDate;
	}
}
