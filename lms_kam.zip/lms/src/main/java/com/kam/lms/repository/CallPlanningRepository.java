package com.kam.lms.repository;

import com.kam.lms.model.CallPlanning;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CallPlanningRepository extends JpaRepository<CallPlanning, Long> {
    List<CallPlanning> findByLastCallDateBefore(LocalDate date);
}
