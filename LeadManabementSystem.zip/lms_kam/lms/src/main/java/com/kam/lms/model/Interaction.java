package com.kam.lms.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "interactions")
public class Interaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "lead_id", nullable = false)
    private Lead lead;
    
    @ManyToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User interactedBy; // The KAM who performed the interaction

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Type type; // Type of interaction: CALL or ORDER

    @Column(nullable = false)
    private String details; // Notes or specifics of the interaction

    @Column(nullable = false)
    private LocalDateTime interactionDate; // When the interaction occurred

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public enum Type {
        CALL,
        ORDER
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Lead getLead() {
		return lead;
	}

	public void setLead(Lead lead) {
		this.lead = lead;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public LocalDateTime getInteractionDate() {
		return interactionDate;
	}

	public void setInteractionDate(LocalDateTime interactionDate) {
		this.interactionDate = interactionDate;
	}

	public User getInteractedBy() {
		return interactedBy;
	}

	public void setInteractedBy(User interactedBy) {
		this.interactedBy = interactedBy;
	}
}
