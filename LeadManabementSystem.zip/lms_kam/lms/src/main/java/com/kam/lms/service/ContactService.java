package com.kam.lms.service;

import com.kam.lms.model.Contact;
import com.kam.lms.model.Restaurant;
import com.kam.lms.repository.ContactRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ContactService {

    private final ContactRepository contactRepository;

    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    public Contact addContact(Contact contact) {
        return contactRepository.save(contact);
    }

    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

    public Optional<Contact> getContactById(Long id) {
        return contactRepository.findById(id);
    }

    public List<Contact> getContactsByRestaurant(Restaurant restaurant) {
        return contactRepository.findByRestaurant(restaurant);
    }

    public void deleteContact(Long id) {
        contactRepository.deleteById(id);
    }
}
