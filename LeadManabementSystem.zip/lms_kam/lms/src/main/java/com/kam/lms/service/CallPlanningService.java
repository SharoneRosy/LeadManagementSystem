package com.kam.lms.service;

import com.kam.lms.model.CallPlanning;
import com.kam.lms.repository.CallPlanningRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class CallPlanningService {

    private final CallPlanningRepository callPlanningRepository;

    public CallPlanningService(CallPlanningRepository callPlanningRepository) {
        this.callPlanningRepository = callPlanningRepository;
    }

    public CallPlanning addOrUpdateCallPlanning(CallPlanning callPlanning) {
        return callPlanningRepository.save(callPlanning);
    }

    public Optional<CallPlanning> getCallPlanningById(Long id) {
        return callPlanningRepository.findById(id);
    }

    public List<CallPlanning> getCallPlanningsDueToday() {
        LocalDate today = LocalDate.now();
        return callPlanningRepository.findByLastCallDateBefore(today.minusDays(1));
    }

    public void deleteCallPlanning(Long id) {
        callPlanningRepository.deleteById(id);
    }
}
