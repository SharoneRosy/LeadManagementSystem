package com.kam.lms.service;

import com.kam.lms.model.Interaction;
import com.kam.lms.model.Lead;
import com.kam.lms.repository.InteractionRepository;
import com.kam.lms.repository.LeadRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PerformanceService {

    private final LeadRepository leadRepository;
    private final InteractionRepository interactionRepository;

    public PerformanceService(LeadRepository leadRepository, InteractionRepository interactionRepository) {
        this.leadRepository = leadRepository;
        this.interactionRepository = interactionRepository;
    }

    public Map<String, Long> getLeadStatusMetrics() {
        Map<String, Long> metrics = new HashMap<>();
        metrics.put("NEW", leadRepository.countByStatus(Lead.Status.NEW));
        metrics.put("IN_PROGRESS", leadRepository.countByStatus(Lead.Status.IN_PROGRESS));
        metrics.put("COMPLETED", leadRepository.countByStatus(Lead.Status.COMPLETED));
        return metrics;
    }

    public List<Interaction> getHighFrequencyInteractions(LocalDate sinceDate) {
        return interactionRepository.findByInteractionDateAfter(sinceDate);
    }

    public Map<String, Long> getOrderPatterns() {
        Map<String, Long> metrics = new HashMap<>();
        long callInteractions = interactionRepository.countByType(Interaction.Type.CALL);
        long orderInteractions = interactionRepository.countByType(Interaction.Type.ORDER);
        metrics.put("CALLS", callInteractions);
        metrics.put("ORDERS", orderInteractions);
        return metrics;
    }

    public Map<String, Object> getKAMPerformance(Long userId) {
        Map<String, Object> performance = new HashMap<>();
        long totalLeads = leadRepository.countByUserId(userId);
        long completedLeads = leadRepository.countByUserIdAndStatus(userId, Lead.Status.COMPLETED);
        performance.put("TOTAL_LEADS", totalLeads);
        performance.put("COMPLETED_LEADS", completedLeads);
        performance.put("COMPLETION_RATE", totalLeads > 0 ? (completedLeads * 100.0 / totalLeads) : 0);
        return performance;
    }
}
