package com.kam.lms.repository;

import com.kam.lms.model.Lead;
import com.kam.lms.model.User;
import com.kam.lms.model.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeadRepository extends JpaRepository<Lead, Long> {
    List<Lead> findByUser(User user);
    List<Lead> findByRestaurant(Restaurant restaurant);
    List<Lead> findByStatus(Lead.Status status);
    long countByStatus(Lead.Status status);
    long countByUserId(Long userId);
    long countByUserIdAndStatus(Long userId, Lead.Status status);
}
