package com.kam.lms.repository;

import com.kam.lms.model.Contact;
import com.kam.lms.model.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ContactRepository extends JpaRepository<Contact, Long> {
    List<Contact> findByRestaurant(Restaurant restaurant);
}
