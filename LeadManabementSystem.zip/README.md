
# Key Account Manager (KAM) Lead Management System

## Overview
This project is designed to manage leads, interactions, and performance metrics for Key Account Managers (KAMs) working with large restaurant accounts. The system offers features for lead tracking, interaction logging, call planning, and performance monitoring.

## Features
- **Lead Management:** Add and track restaurant leads.
- **Contact Management:** Manage multiple Points of Contact (POCs) for each restaurant.
- **Interaction Tracking:** Record calls and track orders placed.
- **Call Planning:** Schedule and monitor call frequency for each lead.
- **Performance Tracking:** Identify well-performing and underperforming accounts.
