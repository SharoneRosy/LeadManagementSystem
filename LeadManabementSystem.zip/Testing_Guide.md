
# Testing Guide

## Unit and Integration Tests
Run the tests using Maven:
```
mvn test
```

## Testing Scenarios
1. Add a new lead and verify it appears in the database.
2. Log an interaction and check if it updates the lead status.
3. Schedule a call and confirm it is added to the schedule.
