
# Installation Guide

## Prerequisites
- Java JDK 17 or higher
- Maven 3.x
- MySQL or another supported database
- IDE (e.g., IntelliJ IDEA)

## Steps
1. Clone the repository:
   ```
   git clone <repository_url>
   ```
2. Navigate to the project directory and install dependencies:
   ```
   mvn clean install
   ```
3. Set up the database using the provided schema in `src/main/resources`.
4. Start the application:
   ```
   mvn spring-boot:run
   ```
