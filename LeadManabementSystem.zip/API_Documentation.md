
# API Documentation

## Overview
This document provides a summary of the REST API endpoints for the Lead Management System.

### Base URL
```
http://localhost:8080/api
```

### Endpoints

#### 1. Leads Management
- **GET /leads**: Retrieve all leads.
- **POST /leads**: Add a new lead.

#### 2. Contacts Management
- **GET /contacts/{leadId}**: Retrieve all contacts for a lead.
- **POST /contacts**: Add a new contact.

#### 3. Interaction Tracking
- **GET /interactions/{leadId}**: Retrieve all interactions for a lead.
- **POST /interactions**: Log a new interaction.

#### 4. Call Planning
- **GET /calls/today**: Retrieve leads requiring calls today.
- **POST /calls/schedule**: Schedule a new call.
